﻿using System;
namespace ChatServer
{
    public class Server
    {
        public Server()
        {
        }
    }
}
